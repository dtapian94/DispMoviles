package mx.itesm.csf.closetskeleton;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

public class inicioDeSesion extends AppCompatActivity {


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.inicio_de_sesion_layout);

        editText2 = findViewById(R.id.editText2);
        editText3 = findViewById(R.id.editText3);
        editText4 = findViewById(R.id.editText4);
        editText5 = findViewById(R.id.editText5);
        editText6 = findViewById(R.id.editText6);


    }


    private EditText editText2,editText3,editText4,editText5,editText6;

    public void guardar(View v) {
        String nombre = editText2.getText().toString();
        String apellido = editText3.getText().toString();
        String correo = editText4.getText().toString();
        String contrasena = editText5.getText().toString();
        String confcontrasena = editText6.getText().toString();

        SharedPreferences preferencias = getSharedPreferences("crm",Context.MODE_PRIVATE);
        SharedPreferences.Editor editor = preferencias.edit();
        editor.putString("nombre", nombre );
        editor.putString("apellido", apellido);
        editor.putString("correo", correo );
        editor.putString("contrasena", contrasena );


        editor.commit();

        Toast.makeText(this, "Datos guardados correctamente", Toast.LENGTH_LONG).show();


    }


}
