package mx.itesm.csf.closetskeleton;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;

public class ingresoDeSesion extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.ingresodesesion);

        Button btn16 = (Button) findViewById(R.id.button7);
        Button btn18 = (Button) findViewById(R.id.button8);

        btn16.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                Intent actividad = new Intent(ingresoDeSesion.this, Menu.class);
                startActivity(actividad);
            }
        });


        btn18.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                Intent actividad = new Intent(ingresoDeSesion.this, inicioDeSesion.class);
                startActivity(actividad);
            }
        });
    }
}
